You can delete this file and folder if you aren't planning to add a playback skin.


A playback skin (also known as a silhouette skin) is the single-colored Madeline you see in the wavedash tutorial in Farewell.
Some maps also use the playback visuals. For example Chromatic Complex and Pinball Purgatory, both from the mod Strawberry Jam Collab.
(https://gamebanana.com/mods/424541)

Playback skins nearly double the image count so they're not included in this template to prevent unnecessary bloat.
After all, many people don't bother reskinning them.
Please join the Celeste discord server and ask for help in the #asset_making channel if you want to add the playback skin. 
(https://discord.com/invite/celeste)

You can also look at existing skins with playback animations. I suggest looking at the Link skinmod by Linkdahl.
(https://gamebanana.com/mods/493129)

Feel free friend requesting me in discord so you can dm me if you don't want to join the server.
My handle is @kuksattu